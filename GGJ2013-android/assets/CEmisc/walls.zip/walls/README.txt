Here's what I had in mind when I started trying to make this work: randomly shifting walls, making every level unique.

The wall tiles:
Originally drawn in 4x4 grids, they had 4 different possible starting and ending points. For example, the top (or bottom) wall could start out with a tile where the wall starts on row 1, and ended on row 1. The next tile in the wall would need to start no more than 1 row above or below the end of the previous tile, but could also travel up to 4 rows in either direction. In this example, say it goes up one row but ends three rows down. The next tile must then start no more than 1 row above or below the ending of that tile, etc etc.

The logic:
If each tile is assigned/grouped by their starting position, my hope was that it wouldn'tbe too difficult to set up guidelines so that the top and bottom walls would constrict and expand based on random values - within a certain threshold, so the player don't end up with too much or too little room.

The problem:
I can't get the tiles into a state where I can easily call each of them specifically, and also associate collision boundaries with them.